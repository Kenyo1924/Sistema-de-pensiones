<?php
// Redirecciona automáticamente a login.php al ingresar al sistema
header("Location: login.php");
exit();
